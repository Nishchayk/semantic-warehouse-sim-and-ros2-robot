import json
import math
import time
from enum import Enum, auto

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String


class State(Enum):
    IDLE = auto()
    NAVIGATE_TO_SHELF = auto()
    AVOID_OBSTACLE = auto()
    NAVIGATE_TO_OUTBOUND = auto()
    MISSION_COMPLETE = auto()


LINEAR_SPEED = 0.15
ANGULAR_GAIN = 1.2
GOAL_TOLERANCE = 0.35
OBSTACLE_DISTANCE = 0.30
AVOID_TURN_SPEED = 0.6
AVOID_CLEAR_STREAK = 8


SHELF_WAYPOINT = (0.8, 0.8)
OUTBOUND_WAYPOINT = (0.3, -0.6)


class DeliveryRobotNode(Node):
    def __init__(self):
        super().__init__('delivery_robot_node')


        self.state = State.IDLE
        self.mission_running = False
        self.current_pose = None
        self.latest_scan_min = float('inf')
        self.clear_streak = 0
        self.mission_start_time = None
        self.distance_travelled = 0.0
        self.last_pose_for_distance = None
        self.collision_count = 0


        self.cmd_vel_pub = self.create_publisher(Twist, '/fastbot/cmd_vel', 10)
        self.status_pub = self.create_publisher(String, '/robot_status', 10)

        self.create_subscription(Odometry, '/fastbot/odom', self.odom_callback, 10)
        self.create_subscription(LaserScan, '/fastbot/scan', self.scan_callback, 10)
        self.create_subscription(String, '/mission_trigger', self.trigger_callback, 10)

        self.create_timer(0.1, self.control_loop)


        self.log_path = 'delivery_mission_log.txt'
        self._log_file = open(self.log_path, 'a')

        self._log(f"Node started. Waiting for /mission_trigger 'start'. "
                   f"Shelf waypoint={SHELF_WAYPOINT}, Outbound waypoint={OUTBOUND_WAYPOINT}")


    def _log(self, message):
        stamp = time.strftime('%Y-%m-%d %H:%M:%S')
        line = f"[{stamp}] {message}"
        self.get_logger().info(message)
        self._log_file.write(line + '\n')
        self._log_file.flush()

    def _set_state(self, new_state, reason=""):
        old_state = self.state
        self.state = new_state
        self._log(f"STATE CHANGE: {old_state.name} -> {new_state.name}"
                   f"{' | ' + reason if reason else ''}")

    def publish_status(self):
        elapsed = (time.time() - self.mission_start_time) if self.mission_start_time else 0.0
        payload = {
            "state": self.state.name,
            "elapsed_seconds": round(elapsed, 2),
            "distance_travelled_m": round(self.distance_travelled, 3),
            "collisions_detected": self.collision_count,
            "pose": self.current_pose,
        }
        msg = String()
        msg.data = json.dumps(payload)
        self.status_pub.publish(msg)


    def odom_callback(self, msg: Odometry):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        q = msg.pose.pose.orientation
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        yaw = math.atan2(siny_cosp, cosy_cosp)

        if self.last_pose_for_distance is not None:
            dx = x - self.last_pose_for_distance[0]
            dy = y - self.last_pose_for_distance[1]
            self.distance_travelled += math.hypot(dx, dy)
        self.last_pose_for_distance = (x, y)
        self.current_pose = (round(x, 3), round(y, 3), round(yaw, 3))

    def scan_callback(self, msg: LaserScan):
        total_readings = len(msg.ranges)
        center = total_readings // 2
        window = total_readings // 12
        front_ranges = msg.ranges[center - window: center + window]

        valid = [r for r in front_ranges if r > 0.0 and not math.isinf(r) and not math.isnan(r)]
        self.latest_scan_min = min(valid) if valid else float('inf')

    def trigger_callback(self, msg: String):
        command = msg.data.strip().lower()
        if command == 'start' and self.state == State.IDLE:
            self.mission_running = True
            self.mission_start_time = time.time()
            self._log("Received 'start' command from HRI (/mission_trigger).")
            self._set_state(State.NAVIGATE_TO_SHELF, "mission started by operator")
        elif command == 'stop':
            self.mission_running = False
            self._log("Received 'stop' command from HRI. Halting robot.")
            self.cmd_vel_pub.publish(Twist())
            self._set_state(State.IDLE, "mission stopped by operator")
    def _drive_toward(self, target_xy):
        """Publishes a Twist that steers the robot toward target_xy.
        Returns True once the robot is within GOAL_TOLERANCE."""
        if self.current_pose is None:
            return False

        x, y, yaw = self.current_pose
        tx, ty = target_xy
        dx, dy = tx - x, ty - y
        distance = math.hypot(dx, dy)

        if distance < GOAL_TOLERANCE:
            self.cmd_vel_pub.publish(Twist())
            return True

        target_heading = math.atan2(dy, dx)
        heading_error = math.atan2(math.sin(target_heading - yaw), math.cos(target_heading - yaw))

        twist = Twist()
        twist.linear.x = LINEAR_SPEED
        twist.angular.z = ANGULAR_GAIN * heading_error
        self.cmd_vel_pub.publish(twist)
        return False

    def _obstacle_ahead(self):
        return self.latest_scan_min < OBSTACLE_DISTANCE
    def control_loop(self):
        if not self.mission_running and self.state == State.IDLE:
            return

        if self.state in (State.NAVIGATE_TO_SHELF, State.NAVIGATE_TO_OUTBOUND):
            if self._obstacle_ahead():
                self.collision_count += 1
                self.clear_streak = 0
                self._pending_state_after_avoid = self.state
                self._set_state(State.AVOID_OBSTACLE,
                                 f"obstacle at {self.latest_scan_min:.2f} m -> switching state")

        if self.state == State.NAVIGATE_TO_SHELF:
            if self._drive_toward(SHELF_WAYPOINT):
                self._log(f"Arrived at shelf waypoint {SHELF_WAYPOINT}.")
                self._set_state(State.NAVIGATE_TO_OUTBOUND, "pickup complete, heading to outbound")

        elif self.state == State.AVOID_OBSTACLE:
            if self._obstacle_ahead():
                self.clear_streak = 0
                self.avoid_turn_accum = getattr(self, 'avoid_turn_accum', 0.0) + AVOID_TURN_SPEED * 0.1
                twist = Twist()
                twist.angular.z = AVOID_TURN_SPEED
                self.cmd_vel_pub.publish(twist)
            else:
                self.clear_streak += 1

            if self.clear_streak < 15:
                twist = Twist()
                twist.angular.z = AVOID_TURN_SPEED
                self.cmd_vel_pub.publish(twist)
            elif self.clear_streak >= 15:
                self.avoid_turn_accum = 0.0
                resume_state = getattr(self, '_pending_state_after_avoid', State.NAVIGATE_TO_SHELF)
                self._set_state(resume_state, "turned clear -> resuming navigation")
        elif self.state == State.NAVIGATE_TO_OUTBOUND:
                if self._drive_toward(OUTBOUND_WAYPOINT):
                    self._log(f"Arrived at outbound waypoint {OUTBOUND_WAYPOINT}.")
                    self._set_state(State.MISSION_COMPLETE, "drop-off complete")

        elif self.state == State.MISSION_COMPLETE:
            self.cmd_vel_pub.publish(Twist())
            if self.mission_running:
                elapsed = time.time() - self.mission_start_time
                self._log(f"MISSION SUMMARY: elapsed={elapsed:.2f}s, "
                          f"distance={self.distance_travelled:.2f}m, "
                          f"collisions_detected={self.collision_count}")
                self.mission_running = False
                self._set_state(State.IDLE, "ready for next mission")

        self.publish_status()

    def destroy_node(self):
        self._log_file.close()
        super().destroy_node()



def main(args=None):
    rclpy.init(args=args)
    node = DeliveryRobotNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        import traceback
        print("=== NODE CRASHED ===")
        traceback.print_exc()
        node._log(f"CRASH: {e}")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
