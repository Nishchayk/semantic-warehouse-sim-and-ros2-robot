import sys
import termios
import tty

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class KeyboardHRINode(Node):
    def __init__(self):
        super().__init__('keyboard_hri_node')
        self.publisher = self.create_publisher(String, '/mission_trigger', 10)
        self.get_logger().info(
            "Keyboard HRI ready. Press 's' to start mission, 'x' to stop, 'q' to quit."
        )

    def publish_command(self, command: str):
        msg = String()
        msg.data = command
        self.publisher.publish(msg)
        self.get_logger().info(f"Published '/mission_trigger' = '{command}'")


def get_single_keypress():
    """Reads one character from stdin without requiring Enter."""
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch


def main(args=None):
    rclpy.init(args=args)
    node = KeyboardHRINode()

    try:
        while rclpy.ok():
            key = get_single_keypress()
            if key == 's':
                node.publish_command('start')
            elif key == 'x':
                node.publish_command('stop')
                
            elif key == 'q':
                node.get_logger().info("Quitting keyboard HRI node.")
                break
            rclpy.spin_once(node, timeout_sec=0.01)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
