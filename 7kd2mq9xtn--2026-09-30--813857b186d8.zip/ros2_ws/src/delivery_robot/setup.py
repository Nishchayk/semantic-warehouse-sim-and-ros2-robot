from setuptools import setup
import os
from glob import glob

package_name = 'delivery_robot'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Student',
    maintainer_email='student@example.com',
    description='Task 2 delivery robot: state machine, navigation, obstacle avoidance, HRI, monitoring.',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'delivery_robot_node = delivery_robot.delivery_robot_node:main',
            'keyboard_hri_node = delivery_robot.keyboard_hri_node:main',
        ],
    },
)
